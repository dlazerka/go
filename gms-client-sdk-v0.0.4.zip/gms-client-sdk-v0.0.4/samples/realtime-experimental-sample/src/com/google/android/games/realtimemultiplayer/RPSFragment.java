// Copyright 2012 Google Inc. All Rights Reserved.

package com.google.android.games.realtimemultiplayer;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

/**
 * Activity to play a match of Rock Paper and Scissors.
 *
 */
public final class RPSFragment extends Fragment implements View.OnClickListener {

    private static final String TAG = "RPSFragment";

    private RealTimeGameActivity mParent;

    private TextView mPlayersView;
    private Button mRockButton;
    private Button mPaperButton;
    private Button mScissorButton;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        mParent = (RealTimeGameActivity) getActivity();

        View view = inflater.inflate(R.layout.rps, container, false);

        mRockButton = (Button) view.findViewById(R.id.rock);
        mRockButton.setOnClickListener(this);

        mPaperButton = (Button) view.findViewById(R.id.paper);
        mPaperButton.setOnClickListener(this);

        mScissorButton = (Button) view.findViewById(R.id.scissor);
        mScissorButton.setOnClickListener(this);

        mPlayersView = (TextView) view.findViewById(R.id.playersView);

        String opponentName = (mParent.getOpponent() == null)
                ? "unknown" : mParent.getOpponent().getDisplayName();
        String formattedText = getResources().getString(R.string.text_view_str,
                opponentName);
        mPlayersView.setText(formattedText);
        return view;
    }

    @Override
    public void onClick(View view) {
        int enteredValue = RealTimeGameActivity.ROCK;
        if (view == mRockButton) {
            enteredValue = RealTimeGameActivity.ROCK;
        } else if (view == mPaperButton) {
            enteredValue = RealTimeGameActivity.PAPER;
        } else if (view == mScissorButton) {
            enteredValue = RealTimeGameActivity.SCISSORS;
        }
        mParent.setSelection(enteredValue);
    }
}
