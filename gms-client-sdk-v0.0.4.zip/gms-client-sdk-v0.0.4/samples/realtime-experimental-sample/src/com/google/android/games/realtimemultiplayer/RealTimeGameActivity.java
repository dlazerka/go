// Copyright 2012 Google Inc. All Rights Reserved.

package com.google.android.games.realtimemultiplayer;

import com.google.android.gms.common.ConnectionStatus;
import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.games.GamesClient;
import com.google.android.gms.games.GamesClient.OnRealTimeMessageSentListener;
import com.google.android.gms.games.GamesClient.RealTimeMatchCallbacks;
import com.google.android.gms.games.data.match.Participant;
import com.google.android.gms.games.data.match.PlayerResult;
import com.google.android.gms.games.data.match.RealTimeMatchImpl;
import com.google.android.gms.games.data.match.RealTimeMatchMessage;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.IntentSender.SendIntentException;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Simple sample application to demonstrate real-time multiple player functionality.
 */
public final class RealTimeGameActivity extends FragmentActivity
        implements ConnectionCallbacks, OnConnectionFailedListener, View.OnClickListener,
        RealTimeMatchCallbacks, OnRealTimeMessageSentListener {

    private static final String TAG = RealTimeGameActivity.class.getSimpleName();

    static final int ROCK = 1;
    static final int PAPER = 2;
    static final int SCISSORS = 3;

    private static final int REQUEST_HANDLE_ERROR = 1;
    private static final int SELECT_PLAYERS = 2;
    private static final int CONTINUE_MATCH_SELECT = 3;

    private Button mNewMatchButton;
    private Button mMatchesButton;

    private GamesClient mGamesClient;
    private String mOpponentPlayerId;
    private Participant mOpponent;
    private RealTimeMatchImpl mMatch;
    private String mInvitationIdToAccept;

    private int mMySelection = -1;
    private int mOpponentSelection = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        // Register the button callbacks
        mNewMatchButton = (Button) findViewById(R.id.new_match_button);
        mNewMatchButton.setOnClickListener(this);
        mNewMatchButton.setEnabled(false);

        mMatchesButton = (Button) findViewById(R.id.load_matches_button);
        mMatchesButton.setOnClickListener(this);
        mMatchesButton.setEnabled(false);

        mGamesClient = new GamesClient(this, getString(R.string.app_id), this, this);

        // Check for an inbound match from the destination on first launch
        if (savedInstanceState == null) {
            RealTimeMatchImpl match = getIntent().getParcelableExtra(
                    GamesClient.EXTRA_REAL_TIME_MATCH);
            if (match != null) {
                mInvitationIdToAccept = match.getMatchId();
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        mGamesClient.connect();
    }

    @Override
    protected void onStop() {
        super.onStop();
        mGamesClient.disconnect();
    }

    @Override
    public void onConnected() {
        mNewMatchButton.setEnabled(true);
        mMatchesButton.setEnabled(true);

        // Accept the inbound invitation from the destination
        if (mInvitationIdToAccept != null) {
            mGamesClient.acceptRealTimeMatchInvite(this, mInvitationIdToAccept);
            mInvitationIdToAccept = null;
        }
    }

    @Override
    public void onConnectionFailed(ConnectionStatus result) {
        int errorCode = result.getErrorCode();
        if (Log.isLoggable(TAG, Log.INFO)) {
            Log.i(TAG, "Connection to service apk failed with error " + errorCode);
        }

        if (result.hasResolution()) {
            try {
                result.startResolutionForResult(this, REQUEST_HANDLE_ERROR);
            } catch (SendIntentException e) {
                Log.e(TAG, "Unable to recover from a connection failure.");
                finish();
            }
        } else if (GooglePlayServicesUtil.isUserRecoverableError(result.getErrorCode())) {
            // TODO: this dialog doesn't handle back pressed correctly yet.
            Dialog dialog = GooglePlayServicesUtil.getErrorDialog(errorCode, this,
                    REQUEST_HANDLE_ERROR);
            dialog.show();
        } else {
            // Unable to recover from a connection error.
            Log.e(TAG, "Unable to recover from a connection failure.");
            finish();
        }
    }

    @Override
    public void onDisconnected() {
        Log.d(TAG, "mGamesClient is disconnected");
    }

    public RealTimeMatchImpl getMatch() {
        return mMatch;
    }

    public void setSelection(int value) {
        mMySelection = value;
        mGamesClient.sendUnreliableRealTimeMatchMessage(
                Integer.toString(mMySelection).getBytes(), mOpponentPlayerId);
        if (mMySelection > 0 && mOpponentSelection > 0) {
            declareWinner();
        }
    }

    public Participant getOpponent() {
        return mOpponent;
    }

    @Override
    public void onClick(View view) {
        if (view == mNewMatchButton) {
            startActivityForResult(mGamesClient.getSelectPlayersIntent(1, 1), SELECT_PLAYERS);
        } else if (view == mMatchesButton) {
            startActivityForResult(mGamesClient.getMatchChooserIntent(), CONTINUE_MATCH_SELECT);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        switch (requestCode) {
            case REQUEST_HANDLE_ERROR:
                if (resultCode == Activity.RESULT_OK) {
                    // We resolved the ConnectionStatus error successfully.
                    // Try to connect again.
                    mGamesClient.connect();
                } else {
                    TextView error = new TextView(this);
                    error.setText(R.string.sign_in_failed);
                    setContentView(error);
                }
                break;
            case SELECT_PLAYERS: {
                if (resultCode == Activity.RESULT_OK) {
                  mOpponentPlayerId =
                          intent.getStringArrayListExtra(GamesClient.EXTRA_PLAYERS).get(0);
                  Log.v(TAG, "Selected Opponents:" + mOpponentPlayerId);
                  startNewMultiplayerMatch();
                }
                break;
            }
        }
    }

    @Override
    public void onRealTimeMatchLoaded(RealTimeMatchImpl match) {
        if (match == null) {
            return;
        }
        mMatch = match;
        Log.v(TAG, "Match Id: " + mMatch.getMatchId());
        for (Participant p : mMatch.getParticipantList()) {
            String currentPlayerId = getPlayerId();
            if (!p.getPlayerId().equals(currentPlayerId)) {
                Log.v(TAG, "Opponents :" + p.getDisplayName());
                Log.v(TAG, "Opponents :" + p.getPlayerId());
                mOpponent = p;
                mOpponentPlayerId = p.getPlayerId();
            }
        }
    }

    @Override
    public void onRealTimeMatchMessageReceived(RealTimeMatchMessage message) {
        mOpponentSelection = Integer.parseInt(new String(message.getMessageData()));
        Log.v(TAG, String.format("Opponent selected = %d", mOpponentSelection));
        if (mMySelection > 0 && mOpponentSelection > 0) {
            declareWinner();
        }
    }

    @Override
    public void onRealTimeMatchReady(String externalMatchId) {
        Log.v(TAG, String.format("Match is Ready for the client = %s", externalMatchId));
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        RPSFragment fragment = new RPSFragment();
        fragmentTransaction.replace(R.id.main_container, fragment);
        fragmentTransaction.commit();
    }

    @Override
    public void onRealTimeMatchCancelled(String externalMatchId) {
        Log.v(TAG, String.format("Match was cancelled =  %s", externalMatchId));
    }

    @Override
    public void onRealTimeMessageSent(int token, String recipientPlayerId) {
        Log.v(TAG, String.format("RealTimeMessage %s sent to : %s", token, recipientPlayerId));
    }

    private String getPlayerId() {
        if (!mGamesClient.isConnected()) throw new IllegalStateException();
        return mGamesClient.getCurrentPlayerId();
    }

    private void startNewMultiplayerMatch() {
        mGamesClient.createRealTimeMatch(this, 1, mOpponentPlayerId);
        Toast.makeText(this, getString(R.string.created_match), Toast.LENGTH_SHORT).show();
    }

    private void declareWinner() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        Resources res = getResources();
        String formattedText = res.getString(R.string.result,
                getStringValue(mMySelection),
                mOpponent.getDisplayName(),
                getStringValue(mOpponentSelection));
        int myMatchResult;
        if (mMySelection == mOpponentSelection) {
            myMatchResult = PlayerResult.MATCH_RESULT_TIE;
            formattedText += res.getString(R.string.draw);
        } else if ((mOpponentSelection == ROCK && mMySelection == PAPER)  ||
            (mOpponentSelection == PAPER && mMySelection == SCISSORS) ||
            (mOpponentSelection == SCISSORS && mMySelection == ROCK)) {
            myMatchResult = PlayerResult.MATCH_RESULT_WIN;
            formattedText += res.getString(R.string.you_won);
        } else {
            myMatchResult = PlayerResult.MATCH_RESULT_LOSS;
            formattedText += res.getString(R.string.opponent_won);
        }
        finishMatch(myMatchResult);
        ResultFragment resultFragment = new ResultFragment(formattedText);
        fragmentTransaction.replace(R.id.main_container,resultFragment);
        fragmentTransaction.commit();
        mMySelection = 0;
        mOpponentSelection = 0;
    }

    private void finishMatch(int myMatchResult) {
        ArrayList<PlayerResult> playerResults = new ArrayList<PlayerResult>(2);
        playerResults.add(new PlayerResult(getPlayerId(),
                myMatchResult, PlayerResult.PLACING_UNINITIALIZED));
        playerResults.add(new PlayerResult(mOpponentPlayerId, getOpponentResult(myMatchResult),
                PlayerResult.PLACING_UNINITIALIZED));
        mGamesClient.finishRealTimeMatch(this, mMatch.getMatchId(), playerResults);
    }

    private int getOpponentResult(int myMatchResult) {
        switch (myMatchResult) {
            case PlayerResult.MATCH_RESULT_LOSS:
                return PlayerResult.MATCH_RESULT_WIN;
            case PlayerResult.MATCH_RESULT_WIN :
                return PlayerResult.MATCH_RESULT_LOSS;
            default :
                return myMatchResult;
        }
    }

    private String getStringValue(int value) {
        Resources res = getResources();
        switch (value) {
            case ROCK :
                return res.getString(R.string.rock);
            case PAPER :
                return res.getString(R.string.paper);
            case SCISSORS :
                return res.getString(R.string.scissor);
        }
        return null;
    }
}
