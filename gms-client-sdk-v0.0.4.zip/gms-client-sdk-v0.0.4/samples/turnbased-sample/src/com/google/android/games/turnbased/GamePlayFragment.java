// Copyright 2012 Google Inc. All Rights Reserved.

package com.google.android.games.turnbased;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

/**
 * Activity to play a match of Rock Paper and Scissors.
 *
 */
public final class GamePlayFragment extends Fragment implements View.OnClickListener {
    private static final String TAG = "GamePlayFragment";

    private TurnBasedGameActivity mParent;

    private View mGamePlayView;
    private TextView mPlayersView;
    private Button mRockButton;
    private Button mPaperButton;
    private Button mScissorButton;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mParent = (TurnBasedGameActivity) getActivity();

        mGamePlayView = inflater.inflate(R.layout.rps, container, false);

        mRockButton = (Button) mGamePlayView.findViewById(R.id.rock);
        mRockButton.setOnClickListener(this);

        mPaperButton = (Button) mGamePlayView.findViewById(R.id.paper);
        mPaperButton.setOnClickListener(this);

        mScissorButton = (Button) mGamePlayView.findViewById(R.id.scissor);
        mScissorButton.setOnClickListener(this);

        mPlayersView = (TextView) mGamePlayView.findViewById(R.id.players_view);

        String opponentName = (mParent.getOpponent() == null)
                ? "unknown" : mParent.getOpponent().getDisplayName();

        String formattedText = getResources().getString(R.string.game_view_state, opponentName);
        mPlayersView.setText(formattedText);
        return mGamePlayView;
    }

    @Override
    public void onClick(View view) {
        int enteredValue = TurnBasedGameActivity.ROCK;
        if (view == mRockButton) {
            enteredValue = TurnBasedGameActivity.ROCK;
        } else if (view == mPaperButton) {
            enteredValue = TurnBasedGameActivity.PAPER;
        } else if (view == mScissorButton) {
            enteredValue = TurnBasedGameActivity.SCISSORS;
        }
        mParent.setSelection(enteredValue);
    }
}
