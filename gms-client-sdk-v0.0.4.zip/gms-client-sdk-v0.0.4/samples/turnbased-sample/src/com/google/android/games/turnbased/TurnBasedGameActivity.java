// Copyright 2012 Google Inc. All Rights Reserved.

package com.google.android.games.turnbased;

import android.support.v4.app.FragmentActivity;
import com.google.android.gms.common.ConnectionStatus;
import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.games.GamesClient;
import com.google.android.gms.games.data.match.Match;
import com.google.android.gms.games.data.match.Participant;
import com.google.android.gms.games.data.match.PlayerResult;
import com.google.android.gms.games.data.match.TurnBasedMatchImpl;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentSender.SendIntentException;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Simple sample application to demonstrate turn-based multiple player functionality.
 */
public final class TurnBasedGameActivity extends FragmentActivity implements ConnectionCallbacks,
        OnConnectionFailedListener, View.OnClickListener, GamesClient.TurnBasedMatchListener {
    private static final String TAG = TurnBasedGameActivity.class.getSimpleName();

    static final int ROCK = 1;
    static final int PAPER = 2;
    static final int SCISSORS = 3;

    private static final int MIN_PLAYERS = 1;
    private static final int MAX_PLAYERS = 1;

    private static final int REQUEST_HANDLE_ERROR = 1;
    private static final int REQUEST_SELECT_PLAYERS = 2;
    private static final int REQUEST_SELECT_MATCH = 3;

    private Button mNewMatchButton;
    private Button mPlayersButton;
    private Button mMatchesButton;
    private TextView mStatusText;

    private GamePlayFragment mGamePlayFragment;
    private GamesClient mGamesClient;
    private String mOpponentPlayerId;
    private Participant mOpponent;
    private TurnBasedMatchImpl mMatch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        mStatusText = (TextView) findViewById(R.id.game_status);

        // Register the button callbacks
        mPlayersButton = (Button) findViewById(R.id.select_players_button);
        mPlayersButton.setOnClickListener(this);
        mPlayersButton.setEnabled(false);

        mNewMatchButton = (Button) findViewById(R.id.new_match_button);
        mNewMatchButton.setOnClickListener(this);
        mNewMatchButton.setEnabled(false);
        mNewMatchButton.setVisibility(View.GONE);

        mMatchesButton = (Button) findViewById(R.id.load_matches_button);
        mMatchesButton.setOnClickListener(this);
        mMatchesButton.setEnabled(false);

        mGamesClient = new GamesClient(this, getString(R.string.app_id), this, this);
        mGamePlayFragment = new GamePlayFragment();

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra(GamesClient.EXTRA_TURN_BASED_MATCH)) {
            mMatch = intent.getParcelableExtra(GamesClient.EXTRA_TURN_BASED_MATCH);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        mGamesClient.connect();
    }

    @Override
    protected void onStop() {
        super.onStop();
        mGamesClient.disconnect();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadGameUI();
    }

    @Override
    public void onConnected() {
        mPlayersButton.setEnabled(true);
        mMatchesButton.setEnabled(true);
        loadGameUI();
    }

    @Override
    public void onConnectionFailed(ConnectionStatus result) {
        int errorCode = result.getErrorCode();
        if (result.hasResolution()) {
            try {
                result.startResolutionForResult(this, REQUEST_HANDLE_ERROR);
            } catch (SendIntentException e) {
                Log.e(TAG, "Unable to recover from a connection failure.");
                finish();
            }
        } else if (GooglePlayServicesUtil.isUserRecoverableError(errorCode)) {
            GooglePlayServicesUtil.getErrorDialog(errorCode, this, REQUEST_HANDLE_ERROR).show();
        } else {
            // Unable to recover from a connection error.
            Log.e(TAG, "Unable to recover from a connection failure.");
            finish();
        }
    }

    @Override
    public void onDisconnected() {
        Log.d(TAG, "mGamesClient is disconnected");
    }

    public void setSelection(int mySelection) {
        byte[] previousState = mMatch.getData();
        byte[] saveState = Integer.toString(mySelection).getBytes();
        mGamesClient.takeTurn(this, mMatch.getMatchId(), saveState, mOpponentPlayerId);

        if (previousState != null) {
            int opponentSelection = Integer.parseInt(new String(previousState));
            if (mySelection > 0 && opponentSelection > 0) {
                declareWinner(mySelection, opponentSelection);
            }
        }
    }

    public Participant getOpponent() {
        return mOpponent;
    }

    @Override
    public void onClick(View view) {
        if (view == mPlayersButton) {
            Intent selectPlayers= mGamesClient.getSelectPlayersIntent(MIN_PLAYERS, MAX_PLAYERS);
            startActivityForResult(selectPlayers, REQUEST_SELECT_PLAYERS);
        } else if (view == mMatchesButton) {
            Intent matchChooser = mGamesClient.getMatchChooserIntent();
            startActivityForResult(matchChooser, REQUEST_SELECT_MATCH);
        } else if (view == mNewMatchButton) {
            mGamesClient.createTurnBasedMatch(this,
                    Match.INVITE_TYPE_INVITE_ALL_NOW, Match.MATCH_VARIANT_ANY, mOpponentPlayerId);
            Toast.makeText(this, getString(R.string.created_match), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        switch (requestCode) {
            case REQUEST_HANDLE_ERROR:
                if (resultCode == Activity.RESULT_OK) {
                    // We resolved the ConnectionStatus error successfully. Connect again.
                    mGamesClient.connect();
                } else {
                    TextView error = new TextView(this);
                    error.setText(R.string.sign_in_failed);
                    setContentView(error);
                }
                break;
            case REQUEST_SELECT_PLAYERS: {
                if (resultCode == Activity.RESULT_OK) {
                  mOpponentPlayerId =
                          intent.getStringArrayListExtra(GamesClient.EXTRA_PLAYERS).get(0);
                  mNewMatchButton.setText(R.string.new_match);
                  mNewMatchButton.setEnabled(true);
                  mNewMatchButton.setVisibility(View.VISIBLE);
                }
                break;
            }
            case REQUEST_SELECT_MATCH: {
                if (intent != null && intent.hasExtra(GamesClient.EXTRA_TURN_BASED_MATCH)) {
                    // Save the match selected by the user. It will be used by loadGameUI from
                    // onResume().
                    mMatch = intent.getParcelableExtra(GamesClient.EXTRA_TURN_BASED_MATCH);
                }
            }
        }
    }

    private void declareWinner(int mySelection, int opponentSelection) {
        Resources res = getResources();
        String formattedText = res.getString(R.string.game_result, getStringValue(mySelection),
                mOpponent.getDisplayName(), getStringValue(opponentSelection));

        int myResult;
        if (mySelection == opponentSelection) {
            myResult = PlayerResult.MATCH_RESULT_TIE;
            formattedText += res.getString(R.string.draw);
        } else if ((opponentSelection == ROCK && mySelection == PAPER)  ||
            (opponentSelection == PAPER && mySelection == SCISSORS) ||
            (opponentSelection == SCISSORS && mySelection == ROCK)) {
            myResult = PlayerResult.MATCH_RESULT_WIN;
            formattedText += res.getString(R.string.you_won);
        } else {
            myResult = PlayerResult.MATCH_RESULT_LOSS;
            formattedText += res.getString(R.string.opponent_won);
        }

        ArrayList<PlayerResult> results = new ArrayList<PlayerResult>(2);
        results.add(new PlayerResult(mGamesClient.getCurrentPlayerId(), myResult,
                PlayerResult.PLACING_UNINITIALIZED));
        results.add(new PlayerResult(mOpponentPlayerId, getOpponentResult(myResult),
                PlayerResult.PLACING_UNINITIALIZED));

        mGamesClient.finishTurnBasedMatch(this, mMatch.getMatchId(), null, results);

        mMatch = null;
        Toast.makeText(this, formattedText, Toast.LENGTH_LONG).show();
    }

    private int getOpponentResult(int myMatchResult) {
        switch (myMatchResult) {
            case PlayerResult.MATCH_RESULT_LOSS:
                return PlayerResult.MATCH_RESULT_WIN;
            case PlayerResult.MATCH_RESULT_WIN :
                return PlayerResult.MATCH_RESULT_LOSS;
            default :
                return myMatchResult;
        }
    }

    private String getStringValue(int value) {
        Resources res = getResources();
        switch (value) {
            case ROCK :
                return res.getString(R.string.rock);
            case PAPER :
                return res.getString(R.string.paper);
            case SCISSORS :
                return res.getString(R.string.scissors);
        }
        return null;
    }

    @Override
    public void onTurnBasedMatchLoaded(TurnBasedMatchImpl match) {
        mMatch = match;
        loadGameUI();
    }

    private void loadGameUI() {
        if (mMatch == null) {
            mStatusText.setText(getString(R.string.game_status_not_loaded));
            findViewById(R.id.game_fragment_holder).setVisibility(View.GONE);
            return;
        }

        switch (mMatch.getStatus()) {
            case Match.MATCH_STATUS_ACTIVE:
                // Load participants into the match.
                for (Participant p : mMatch.getParticipantList()) {
                    String currentPlayerId = mGamesClient.getCurrentPlayerId();
                    if (!p.getPlayerId().equals(currentPlayerId)) {
                        mOpponent = p;
                        mOpponentPlayerId = p.getPlayerId();
                    }
                }

                if (mGamesClient.getCurrentPlayerId().equals(mMatch.getPendingPlayerId())) {
                    // It is the current player's turn.
                    mStatusText.setText(getString(R.string.game_status_my_turn));
                    mGamePlayFragment = new GamePlayFragment();
                    findViewById(R.id.game_fragment_holder).setVisibility(View.VISIBLE);
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.game_fragment_holder, mGamePlayFragment)
                            .commitAllowingStateLoss();
                } else {
                    // Wait for the opponent to make a move.
                    mStatusText.setText(getString(R.string.game_status_waiting));
                    findViewById(R.id.game_fragment_holder).setVisibility(View.GONE);
                }
                break;

            case Match.MATCH_STATUS_COMPLETE:
                mStatusText.setText(getString(R.string.game_status_complete));
                findViewById(R.id.game_fragment_holder).setVisibility(View.GONE);
                break;

            case Match.MATCH_STATUS_INVITING:
                mStatusText.setText(getString(R.string.game_status_inviting));
                findViewById(R.id.game_fragment_holder).setVisibility(View.GONE);
                break;
        }
    }
}
